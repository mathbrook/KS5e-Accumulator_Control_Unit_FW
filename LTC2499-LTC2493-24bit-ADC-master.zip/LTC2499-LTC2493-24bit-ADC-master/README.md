# LTC2499-LTC2493-24bit-ADC
This library can be used for:  
LTC2493: 2/4  channel 24bit ADC  
LTC2499: 8/16 channel 24bit ADC   

This library contains the ADC part of the combined library Ard2499 which contains the libraries for the LTC2499 24bit ADC and the 24AA025E48 EEPROM 

See the 16-Channel 24-Bit ADC Data Acquisition Shield for Arduino from Iowa Scaled Engineering: 
https://www.iascaled.com/store/ARD-LTC2499

https://github.com/IowaScaledEngineering/ard-ltc2499
